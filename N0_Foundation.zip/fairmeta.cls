%
% Copyright (c) Meta Platforms, Inc. and affiliates.
%
% This source code is licensed under the MIT license found in the LICENSE file
% in the root directory of this source tree.
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% A new style for FAIR pre-prints
% Author: dlp@meta.com
% Version: 1.1
% Stripped to the minimum required
%
% MODIFICATIONS (for the NeoVTLA technical report, retains the MIT license):
%   - The title-block logo is no longer hard-wired to Meta's trademarked
%     "logometa.pdf". Use \logo{<file>} to set your own logo; if none is set
%     (or the file is missing) the title card renders without a logo. This
%     avoids shipping Meta's trademark while keeping the identical layout.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Class declarations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{fairmeta}[2024/01/01 v1.1 FAIR-style preprint class (logo-swappable)]
\LoadClassWithOptions{article}

% Layout %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage[margin=1in]{geometry}
\RequirePackage{microtype}
\RequirePackage{placeins}
\RequirePackage{hyphenat}
\RequirePackage{setspace}
\RequirePackage{etoolbox}

% Tables %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage{nicematrix}

% Colorful stuff %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage[most]{tcolorbox}
\RequirePackage{xcolor}
\definecolor{metablue}{HTML}{0064E0}
\definecolor{metafg}{HTML}{1C2B33}
\definecolor{metabg}{HTML}{F1F4F7}

% Section, caption, and font format %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\RequirePackage{titlesec}
\titleformat*{\paragraph}{\itshape}
\titleformat*{\section}{\Large\sffamily\bfseries}
\titleformat*{\subsection}{\large\sffamily\bfseries}
\titleformat*{\subsubsection}{\normalsize\sffamily\bfseries}
\DeclareTextFontCommand{\textbf}{\bfseries\sffamily}

\RequirePackage{caption}
\DeclareCaptionLabelSeparator{custom}{}
\DeclareCaptionFormat{custom}{{\sffamily\textbf{#1 #2}} #3}
\captionsetup{singlelinecheck=false,format=custom,labelsep=custom,font=small}
\captionsetup[sub]{singlelinecheck=true,format=custom,labelsep=custom,font=small}

\renewcommand*\ttdefault{cmvtt}
\newif\iffairmeta@nativefonts
\ifdefined\XeTeXrevision
  \fairmeta@nativefontstrue
\fi
\ifdefined\directlua
  \fairmeta@nativefontstrue
\fi
\iffairmeta@nativefonts
  \RequirePackage{fontspec}
  \setsansfont[Path=assets/,Scale=0.88]{Optimistic.ttf}
\else
  \RequirePackage[T1]{fontenc}
  \DeclareFontFamily{T1}{optimistic}{}
  \DeclareFontShape{T1}{optimistic}{m}{n}{<-> s * [0.88] assets/optimistic}{}
  \DeclareFontShape{T1}{optimistic}{b}{n}{<-> s * [0.88] assets/optimistic}{}
  \pdfmapline{+optimistic < assets/Optimistic.ttf <T1-WGL4.enc}
  \renewcommand{\sfdefault}{optimistic}
\fi

% Logo (swappable) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\newcommand{\@logofile}{}
\newcommand{\logo}[1]{\renewcommand{\@logofile}{#1}}
% Logo width in the title card (default 1cm suits a square icon; widen for a
% horizontal wordmark, e.g. \logowidth{2.8cm}).
\newcommand{\@logowidth}{1cm}
\newcommand{\logowidth}[1]{\renewcommand{\@logowidth}{#1}}
% Optional second logo stacked ABOVE the main logo in the title card (e.g. an
% institutional wordmark). Set with \toplogo{<file>}; width via \toplogowidth.
\newcommand{\@toplogofile}{}
\newcommand{\toplogo}[1]{\renewcommand{\@toplogofile}{#1}}
\newcommand{\@toplogowidth}{2.8cm}
\newcommand{\toplogowidth}[1]{\renewcommand{\@toplogowidth}{#1}}

% Authors, affiliations, infos %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\renewcommand\addtolist[5][]{
  \begingroup
    \if\relax#3\relax\def\sep{}\else\def\sep{#5}\fi
    \let\protect\@unexpandable@protect
    \xdef#3{\expandafter{#3}\sep #4[#1]{#2}}%
  \endgroup
}

\newcommand\authorlist{}
\newcommand\authorformat[2][]{{\sffamily\bfseries #2$^{#1}$}}
\renewcommand\author[2][]{\addtolist[#1]{#2}{\authorlist}{\authorformat}{, }}

\newcommand\affiliationlist{}
\newcommand\affiliationformat[2][]{{\normalsize $^{#1}$#2}}
\newcommand\affiliation[2][]{\addtolist[#1]{#2}{\affiliationlist}{\affiliationformat}{, }}

\newcommand\contributionlist{}
\newcommand\contributionformat[2][]{{\small $^{#1}$#2}}
\newcommand\contribution[2][]{\addtolist[#1]{#2}{\contributionlist}{\contributionformat}{, }}

\newcommand\metadatalist{}
\newcommand\metadataformat[2][]{{\small {\sffamily\bfseries #1:} #2}}
\newcommand\metadata[2][]{\addtolist[#1]{#2}{\metadatalist}{\metadataformat}{\par}}

\renewcommand{\abstract}[1]{\newcommand{\abstractlist}{{\color{metafg} #1}}}
\newcommand{\email}[1]{\href{mailto:#1}{\texttt{#1}}}

\renewcommand\date[1]{\metadata[Date]{#1}}
\newcommand\correspondence[1]{\metadata[Correspondence]{#1}}

\renewcommand{\title}[1]{\newcommand{\titlelist}{{\huge\sffamily\bfseries #1}}}

% Titlebox %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\newcommand{\mymaketitle}{%
  \tcbset{enhanced,frame hidden}
  \tcbset{left=0.5cm}
  \tcbset{right=0.5cm}
  \tcbset{top=0.5cm}
  \tcbset{bottom=0.5cm}
  \tcbset{arc=10pt}
  \tcbset{colback=metabg}
  \tcbset{before skip=0pt}
  \tcbset{grow to left by=1.5pt}
  \tcbset{grow to right by=1.5pt}
  \tcbset{overlay={%
    \ifx\@logofile\empty\else
      \IfFileExists{\@logofile}{%
        \node[anchor=south east, at=(frame.south east),
              xshift=-0.5cm, yshift=0.5cm]
          {\ifx\@toplogofile\empty
             \includegraphics[width=\@logowidth]{\@logofile}%
           \else
             % neoteai logo on top, secondary logo stacked below (right-aligned).
             \shortstack[r]{%
               \includegraphics[width=\@logowidth]{\@logofile}\\[5pt]
               \IfFileExists{\@toplogofile}%
                 {\includegraphics[width=\@toplogowidth]{\@toplogofile}\hspace{-12pt}}{}}%
           \fi};%
      }{}%
    \fi}}
  %
  \begin{tcolorbox}
    \setlength{\parindent}{0cm}
    \setlength{\parskip}{0.5cm}
    {
      \setlength{\parskip}{0cm}
      \centering
      %
      {
        \setstretch{1.618}
        \titlelist\par
      }
      \vskip 0.2cm
      %
      \authorlist\par
      \vskip 0.2cm
      %
      \affiliationlist\par
      %
      \contributionlist\par
    }
    %
    \abstractlist\par
    %
    \vskip 0.5cm
    %
    {
      \setlength{\parskip}{0cm}
      \ifdefempty{\metadatalist}{\vspace*{0.65cm}}{\metadatalist\par}
    }
  \end{tcolorbox}
  \tcbset{reset}
  \FloatBarrier
}

\if@twocolumn%
\renewcommand{\maketitle}{
\twocolumn[%
  \mymaketitle
  \vskip 0.38cm
]
}%
\else%
\renewcommand{\maketitle}{
  \mymaketitle
}%
\fi
