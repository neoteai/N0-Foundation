# NeoData — Technical Report

The NeoData technical report, re-typeset in the **Meta / FAIR-style layout**
from `neoteai-paper-template` (single-column, gray rounded title card, NeoteAI
navy accent, colored headings/links). Content is the original `NeoData_ol`
document; the layout comes from `fairmeta.cls`.

## Build

Requires a full TeX Live (`pdflatex` + `bibtex`) with the packages the class
pulls in: `geometry`, `placeins`, `setspace`, `nicematrix`, `tcolorbox`,
`xcolor`, `hyperref`, `natbib`, `booktabs`, plus `pifont` (comparison-table
check marks).

```sh
make          # pdflatex -> bibtex -> pdflatex x2  ->  main.pdf
make clean    # remove aux files
```

Or by hand:

```sh
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
```

The compiled result is `main.pdf` (21 pages).

## Files

| Path                | Purpose                                                         |
|---------------------|-----------------------------------------------------------------|
| `main.tex`          | Config + title block; `\input`s each section.                   |
| `sec/`              | One `.tex` per section (original NeoData content).              |
| `fairmeta.cls`      | FAIR-style document class (MIT), from the template.             |
| `main.bib`          | Bibliography (natbib, numbered IEEE style).                     |
| `ieeenat_fullname.bst` | Numbered IEEE citation style.                                |
| `figures/`          | All figures, including `figures/tasks/` for the NeoSim suite.   |
| `logo-neoteai*.png` | NeoteAI title-block logos (`-neoteai` active, `-cn`, `-mark`).  |
| `Makefile`          | Build shortcuts.                                                 |

## What changed from `NeoData_ol`

The section text is unchanged. The adaptation to the template is confined to
the preamble and a few bibliography/label fixes:

- **Layout** — replaced the plain `article` preamble (red draft headings,
  `mathptmx`) with `\documentclass{fairmeta}` and the template's title block:
  `\title`, `\author`/`\affiliation`, `\abstract{...}`, `\logo`, brand navy
  `metablue = #26527A`, table of contents.
- **Abstract** — unwrapped from the `abstract` environment into the class's
  `\abstract{...}` command (`sec/1_abstract.tex`).
- **Citations** — kept numbered IEEE style (`natbib` `[numbers]` +
  `ieeenat_fullname.bst`). Completed `main.bib` with 16 standard references
  that were cited but missing from the original bib (RT-1, Open X-Embodiment,
  Diffusion Policy, BridgeData V2, RoboMimic, DROID, GelSight, DIGIT, DINOv2,
  Touch and Go, MAE, I-JEPA, Taxim, MuJoCo, ACT, Calandra et al.).
- **Fixed a duplicate figure label** — the Neote TacUMI overview figure in
  `sec/4_hardware.tex` reused `fig:tactile-sensor-structure`; it is now
  `fig:tacumi-overview`.

The report renders with **no undefined citations or references**.
